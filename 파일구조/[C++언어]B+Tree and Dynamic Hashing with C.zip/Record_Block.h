#include <iostream>
#include <fstream>
#include <string>

#define BLOCKSIZE  4096
#define BLOCKCOUNT 12000                                             
#define IN_BLOCK_MAX  BLOCKSIZE/sizeof(Student)                      // 95
#pragma pack(1)
using namespace std;

// ************************************************************************************************
// **************************************** Student Class *****************************************
// ************************************************************************************************
class Student{
public :
	char  Name[20];
	int   ID;
	float Score;
	char  Dept[10];
	Student();
};

// ************************************************************************************************
// ***************************************** Block Class ******************************************
// ************************************************************************************************
class Block{
public :
	Student Record[BLOCKSIZE/sizeof(Student)];                       // 95���� Record�� �ϳ��� Block�ȿ� ����.
	Block();
	int  Record_Count;                                               // �ϳ��� Block���� ����� Record�� ����.
	int  Bit_Num;																	
	char Block_Garbage[3];                                           // 4096Byte�� ���߱� ���Ͽ� ���� 3Byte�� ó��.
};
